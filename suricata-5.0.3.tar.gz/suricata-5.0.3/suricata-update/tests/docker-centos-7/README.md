This is a live test of Suricata-Update in a CentOS 7 Docker image.

The following tests are performed:
- Unit tests with Python 2 and Python 3.
- Installation with Python 2 pip.
- Various commands run as a user might with Python 2 install.
- Installation with Python 3 pip.
- Various commands run as a user might with Python 3 install.

This test is "live" as the index and rule files will be downloaded
from the internet.
